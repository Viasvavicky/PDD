<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "trachcare";
$port = 3307;

$conn = new mysqli($host, $user, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$admin_id = $_POST['admin_id'];
$password = $_POST['password'];

$query = "SELECT * FROM admin WHERE admin_id = '$admin_id' AND password = '$password'";
$result = $conn->query($query);

$response = array();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $response['success'] = true;
    $response['admin_id'] = $row['admin_id'];
    $response['name'] = $row['name'];
} else {
    $response['success'] = false;
    $response['message'] = "Invalid credentials";
}

echo json_encode($response);
$conn->close();
?>
