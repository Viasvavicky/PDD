<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "trachcare";
$port = 3307;

$conn = new mysqli($host, $user, $password, $dbname, $port);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $address = $_POST['address'];
    $patient_id = $_POST['patient_id'];
    $password = $_POST['password'];
    $bmi = $_POST['bmi'];
    $diagnosis = $_POST['diagnosis'];
    $surgery = $_POST['surgery_status'];
    $post_op_day = $_POST['post_op_day'];
    $tube_size = $_POST['tube_size'];
    $baseline_vitals = $_POST['baseline_vitals'];
    $rr = $_POST['respiratory_rate'];

    $query = "INSERT INTO patients (patient_id ,password ,name, age, address, bmi, diagnosis, surgery_status, post_op_day, tube_name_size, baseline_vitals, respiratory_rate)
              VALUES ('$patient_id','$password','$name', '$age', '$address', '$bmi', '$diagnosis', '$surgery', '$post_op_day', '$tube_size', '$baseline_vitals', '$rr')";

    if ($conn->query($query) === TRUE) {
        echo json_encode(["success" => true, "message" => "Patient added successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "Error: " . $conn->error]);
    }
}
?>
