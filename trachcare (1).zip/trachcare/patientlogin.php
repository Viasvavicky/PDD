<?php
$conn = new mysqli("localhost", "root", "", "trachcare");

$patient_id = $_POST['patient_id'];
$password = $_POST['password'];

$query = "SELECT * FROM patients WHERE patient_id = '$patient_id' AND password = '$password'";
$result = mysqli_query($conn, $query);

$response = array();

if (mysqli_num_rows($result) > 0) {
    $response['status'] = 'success';
} else {
    $response['status'] = 'fail';
}

echo json_encode($response);
?>
