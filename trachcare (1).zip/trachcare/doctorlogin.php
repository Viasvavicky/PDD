<?php
$conn = new mysqli("localhost", "root", "", "trachcare",3307);

$doctor_id = $_POST['doctor_id'];
$password = $_POST['password'];

$query = "SELECT * FROM doctors WHERE doctor_reg_no = '$doctor_id' AND password = '$password'";
$result = mysqli_query($conn, $query);

$response = array();

if (mysqli_num_rows($result) > 0) {
    $response['status'] = 'success';
    $response['name'] = $row['username'];
} else {
    $response['status'] = 'fail';
}

echo json_encode($response);
?>
