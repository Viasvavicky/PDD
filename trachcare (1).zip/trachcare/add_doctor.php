<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "trachcare";
$port = 3307;

$conn = new mysqli($host, $user, $password, $dbname, $port);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed']));
}

$name = $_POST['name'];
$doctor_reg_no = $_POST['doctor_reg_no'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];
$qualification = $_POST['qualification'];

$stmt = $conn->prepare("INSERT INTO doctors (username, doctor_reg_no, email, phone, password, qualification) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssss", $name, $doctor_reg_no, $email, $phone, $password, $qualification);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Doctor added successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to add doctor']);
}

$stmt->close();
$conn->close();
?>
